# Endless running game &amp; music player app

This was the final project for the Interactive Graphics course in MSc in Engineering in Computer Science at La 
Sapienza – University of Rome

To start the game download the files and start a local host server

a- An endless running game.
b- A small interactive cinematic scene with music player

Note: This is just a demo, when your score reaches 100 the game will stop or if 30 seconds pass the game will stop also.
The Home Page contains a menu where the player can choose which game/app wants to try

Environments
i. Three.js
It is an easy to use, lightweight, 3D library. The library provides <canvas>, <svg>, CSS3D and WebGL renderers. The library itself is written in JavaScript and is intended to be used in a JavaScript environment. For the most part this means that it will run client side -in a web browser on some device.
ii. WebGL
WebGL is a JavaScript API for rendering interactive 3D and 2D graphics within a web browser on a<canvas> element.

Live demo

https://sapienzainteractivegraphicscourse.github.io/final-project-soloteam/

